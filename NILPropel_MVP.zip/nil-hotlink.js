(async function () {
    const response = await fetch('athletes.json');
    const athletes = await response.json();

    function linkifyTextNodes(node) {
        if (node.nodeType === Node.TEXT_NODE && node.nodeValue.trim()) {
            let newHTML = node.nodeValue;
            athletes.forEach(athlete => {
                const regex = new RegExp(`\\b${athlete.name}\\b`, 'gi');
                newHTML = newHTML.replace(regex, `<a href="${athlete.url}" target="_blank" class="nil-hotlink">${athlete.name}</a>`);
            });

            if (newHTML !== node.nodeValue) {
                const span = document.createElement('span');
                span.innerHTML = newHTML;
                node.replaceWith(span);
            }
        } else if (node.nodeType === Node.ELEMENT_NODE) {
            node.childNodes.forEach(linkifyTextNodes);
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        linkifyTextNodes(document.body);
    });
})();