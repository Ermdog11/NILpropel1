# NILPropel MVP

## Instructions

1. Go to Vercel Dashboard → Click '+ New Project' → 'Upload'.
2. Drag this entire folder and deploy it.
3. After deploy, your script will be live (e.g., https://yourapp.vercel.app/nil-hotlink.js).
4. Add this script to any website header:

<script src="https://yourapp.vercel.app/nil-hotlink.js" defer></script>

5. Edit athletes.json and redeploy anytime to update links.
